// Importiamo gli hook useEffect e useState da React che ci servono per gestire lo stato e gli effetti collaterali
import {useEffect, useState} from 'react';
// Importiamo il componente ListaCommenti che visualizzerà la lista dei commenti
import ListaCommenti from './ListaCommenti';
// Importiamo il componente AggiungiCommento che gestirà l'aggiunta di nuovi commenti
import AggiungiCommento from './AggiungiCommento';

// Definiamo il componente AreaCommenti che riceve il codice del libro come prop
const AreaCommenti = ({codiceLibro}) => {
    // Stato per memorizzare l'array dei commenti
    const [commenti, setCommenti] = useState([]);
    // Stato per gestire lo stato di caricamento
    const [caricamento, setCaricamento] = useState(true);
    // Stato per gestire eventuali errori
    const [errore, setErrore] = useState(null);
    // Token di autenticazione per le chiamate API
    const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NzdjZjQyNjdjMWUwYjAwMTUxNzIxYWQiLCJpYXQiOjE3Mzc3NDA4ODEsImV4cCI6MTczODk1MDQ4MX0.X23fXNuGqMToGB2A0VIYWqvOIJXXMpVOWIXD4Eij-gc";

    // Funzione per caricare i commenti dal server
    const caricaCommenti = () => {
        // Chiamata fetch all'API con il codice del libro
        fetch(`https://striveschool-api.herokuapp.com/api/books/${codiceLibro}/comments`, {
            headers: {
                // Includiamo il token di autorizzazione nell'header
                "Authorization": `Bearer ${token}`
            }
        })
        .then((response ) => {
            // Verifichiamo se la risposta è ok
            if (response.ok) {
                return response.json();
            } else {
                // Se non è ok, lanciamo un errore
                throw new Error("Errore nel caricamento dei commenti");
            }
        })
        .then((data) => {
            // Aggiorniamo lo stato dei commenti con i dati ricevuti
            setCommenti(data);
            // Resettiamo lo stato di errore
            setErrore(null);
        })
        .catch((error) => {
            // In caso di errore, lo memorizziamo nello stato
            setErrore(error.message);
        })
        .finally(() => {
            // Alla fine, indipendentemente dal risultato, impostiamo caricamento a false
            setCaricamento(false);
        })
    }

    // useEffect per caricare i commenti quando il componente viene montato o quando cambia il codice del libro
    useEffect(() => {
        caricaCommenti();
    }, [codiceLibro]);

    // Rendering del componente
    return (
        // Container principale per l'area commenti
        <div className="area-commenti mt-3">
            {/* Mostra messaggio di caricamento se necessario */}
            {caricamento && <p>Caricamento commenti...</p>}
            {/* Mostra messaggio di errore se presente */}
            {errore && <p className="text-danger">Attenzione: {errore}</p>}
            {/* Componente per visualizzare la lista dei commenti */}
            <ListaCommenti
            commenti={commenti}
            token={token}
            onCommentoEliminato={caricaCommenti}
            onCommentoModificato={caricaCommenti}
             />
            {/* Componente per aggiungere nuovi commenti */}
            <AggiungiCommento 
            codiceLibro={codiceLibro} 
            onCommentoAggiunto={caricaCommenti}
            token={token} />
        </div>
    )
}

// Esportiamo il componente per utilizzarlo in altre parti dell'applicazione
export default AreaCommenti;