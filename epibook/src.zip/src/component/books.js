import { Col, Row } from 'react-bootstrap';
import fantasy from '../dati/fantasy.json';
import history from '../dati/history.json';
import romance from '../dati/romance.json';
import scifi from '../dati/scifi.json';
import horror from '../dati/horror.json';
import SingleBook from './SingleBook.js';

const generi = {
    fantasy,
    history,
    romance,
    scifi,
    horror
}

const Books = ({ searchQuery, sceltaGenere = 'all' }) => {
    // Creiamo un Set di libri unici basato sull'ASIN
    const getUniqueBooks = (books) => {
        const uniqueBooks = new Map();
        books.forEach(book => {
            if (!uniqueBooks.has(book.asin)) {
                uniqueBooks.set(book.asin, book);
            }
        });
        return Array.from(uniqueBooks.values());
    };

    const currentBooks = sceltaGenere === 'all'
        ? getUniqueBooks(Object.values(generi).flat()) // Applica il filtro di unicità
        : generi[sceltaGenere];

    const FilteredBooks = currentBooks.filter((libro) => {
        return libro.title.toLowerCase().includes(searchQuery.toLowerCase());
    });

    return (
        <Row>
            {FilteredBooks.map((libro) => {
                return (
                    <Col key={`${libro.asin}-${libro.category}`} sm={6} md={4} lg={3} xl={3}>
                        <SingleBook book={libro} />
                    </Col>
                )
            })}
        </Row>
    )
}

export default Books;