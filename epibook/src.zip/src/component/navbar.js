import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Form from 'react-bootstrap/Form';

function MyNavbar({onGenereChange, onSearchChange}) {

    const genere = ['fantasy', 'horror', 'history', 'romance', 'scifi'];

    return (
        <Navbar expand="lg" className="bg-body-tertiary">
            <Container>
                <Navbar.Brand href="#home">Epibook</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <Nav.Link href="#home">Home</Nav.Link>

                        <NavDropdown title="Generi" id="basic-nav-dropdown">
                            <NavDropdown.Item
                                onClick={() => onGenereChange ('all')}>
                                Tutti
                            </NavDropdown.Item>
                            <NavDropdown.Divider />
                            {genere.map((genere) => {
                                return (
                                    <NavDropdown.Item
                                        key={genere}
                                        href={`#/${genere}`}
                                        onClick={() => onGenereChange(genere)}>
                                        {genere}
                                    </NavDropdown.Item>
                                )
                            })}
                        </NavDropdown>
                    </Nav>
                    <Form className="d-flex">
                        <Form.Control
                            type="search"
                            placeholder="Cerca un libro"
                            className="me-2 df-search-input"
                            aria-label="Search"
                            // Invia il valore di ricerca al componente padre
                            onChange={(e) => onSearchChange(e.target.value)}
                        />
                    </Form>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
}

export default MyNavbar;