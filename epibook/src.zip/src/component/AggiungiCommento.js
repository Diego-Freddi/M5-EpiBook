// Importiamo useState da React per gestire lo stato del componente
import { useState } from 'react';
// Importiamo i componenti Form e Button da react-bootstrap per l'interfaccia utente
import {Form, Button} from 'react-bootstrap';

// Definiamo il componente AggiungiCommento che riceve codiceLibro, onCommentoAggiunto e token come props
const AggiungiCommento = ({codiceLibro, onCommentoAggiunto, token}) => {
    // Stato per gestire il testo del commento
    const [commento, setCommento] = useState('');
    // Stato per gestire il voto (da 1 a 5)
    const [voto, setVoto] = useState(1);
    // Stato per gestire lo stato di invio del form
    const [invioInCorso, setInvioInCorso] = useState(false);
    // Stato per gestire eventuali errori
    const [errore, setErrore] = useState(null);

    // Funzione che gestisce l'invio del form
    const handleSubmit = (e) => {
        // Previene il comportamento di default del form
        e.preventDefault();
        // Imposta lo stato di invio a true
        setInvioInCorso(true);
        // Resetta eventuali errori precedenti
        setErrore(null);
        
        // Effettua la chiamata POST all'API
        fetch('https://striveschool-api.herokuapp.com/api/comments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${token}`
            },
            // Corpo della richiesta con i dati del commento
            body: JSON.stringify({
                comment: commento,
                rate: voto,
                elementId: codiceLibro
            })
        })
        .then((response) => {
            // Verifica se la risposta è ok
            if (response.ok) {
                return response.json();
            } else {
                // Se la risposta non è ok, estrae il testo dell'errore
                return response.text().then(text => {
                    throw new Error(`Errore durante l'invio del commento: ${text}`);
                });            
            }
        })
        .then(() => {
            // Se tutto va bene, aggiorna la lista dei commenti
            onCommentoAggiunto();
            // Resetta il form
            setCommento('');
            setVoto(1);
        })
        .catch((error) => {
            // Gestisce eventuali errori
            setErrore(error.message);
        })
        .finally(() => {
            // Alla fine, indipendentemente dal risultato, imposta invioInCorso a false
            setInvioInCorso(false);
        })
    }

    // Rendering del componente
    return (
        // Form con margine superiore
        <Form onSubmit={handleSubmit} className='mt-4'>
            {/* Gruppo per il campo del commento */}
            <Form.Group className='mb-3'>
                <Form.Label>Commento</Form.Label>
                <Form.Control
                as='textarea'
                rows={3}
                value={commento}
                onChange={(e) => setCommento(e.target.value)}
                required
                />
            </Form.Group>
            {/* Gruppo per il campo del voto */}
            <Form.Group className='mb-3'>
                <Form.Label>Voto</Form.Label>
                <Form.Select
                    value={voto}
                    onChange={(e) => setVoto(parseInt(e.target.value))}
                >
                     {[1, 2, 3, 4, 5].map((num) => (
                        <option key={num} value={num}>{num}</option>
                    ))}
                    {/* <option value={1}>1</option>
                    <option value={2}>2</option>
                    <option value={3}>3</option>
                    <option value={4}>4</option>
                    <option value={5}>5</option> */}
                </Form.Select>
            </Form.Group>
            {/* Mostra eventuali messaggi di errore */}
            {errore && <p className='text-danger'>{errore}</p>}

            {/* Pulsante di invio che si disabilita durante l'invio */}
            <Button
                type='submit'
                disabled={invioInCorso}
            >
                {invioInCorso ? 'Invio in corso...' : 'Invia'}
            </Button>
        </Form>
    )   
}

// Esportiamo il componente per utilizzarlo in altre parti dell'applicazione
export default AggiungiCommento;