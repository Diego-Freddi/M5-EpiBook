// Importiamo il componente Card da react-bootstrap per creare una card stilizzata
import { Card } from 'react-bootstrap';
// Importiamo useState da react per gestire lo stato del componente
import { useState } from 'react';
// Importiamo il componente AreaCommenti che gestirà i commenti del libro
import AreaCommenti from './AreaCommenti';

// Definiamo il componente SingleBook che riceve un oggetto book come prop
const SingleBook = ({book}) => {

    // Creiamo uno stato 'selected' per gestire la selezione della card
    const [selected, setSelected] = useState(false);

    return (
        // Fragment vuoto per wrappare più elementi JSX
        <>
        {/* Card cliccabile che cambia stile quando selezionata */}
        <Card
        className={`book-card ${selected ? 'selected' : ''} mt-3`}
        onClick={() => setSelected(!selected)}
        >
            {/* Container per l'immagine del libro con stile background */}
            <div className="img-container"
            style={{
                height: '25rem', // Altezza fissa del container
                backgroundImage: `url(${book.img})`, // Immagine del libro come sfondo
                backgroundSize: 'cover', // Copre tutto il container
                backgroundPosition: 'center', // Centrata
                backgroundRepeat: 'no-repeat', // Non ripetuta
            }}>
                
            </div>  
            {/* Corpo della card con titolo e dettagli */}
            <Card.Body>
                {/* Titolo troncato a 10 caratteri */}
                <Card.Title className='flex-grow-1'>{book.title.substring(0, 25)}...</Card.Title>
                {/* Container flex per categoria e prezzo */}
                <div className='d-flex justify-content-between'>
                    <Card.Text>{book.category}</Card.Text>
                    <Card.Text>{book.price}€</Card.Text>
                </div>
            </Card.Body>    
        </Card>
        {/* Mostra l'area commenti solo quando la card è selezionata */}
        {selected && <AreaCommenti codiceLibro={book.asin} />}
        </>
    )
}

// Esportiamo il componente per utilizzarlo in altre parti dell'applicazione
export default SingleBook;  