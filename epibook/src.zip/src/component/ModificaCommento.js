// Importiamo useState da React per gestire lo stato del componente
import { useState } from 'react';
// Importiamo i componenti Form e Button da react-bootstrap per l'interfaccia utente
import { Form, Button } from 'react-bootstrap';

// Definiamo il componente ModificaCommento che riceve come props:
// - commento: il commento da modificare
// - token: token di autenticazione per le chiamate API
// - onModificaCompletata: callback da chiamare quando la modifica è completata
// - onAnnulla: callback da chiamare quando si annulla la modifica
const ModificaCommento = ({ commento, token, onModificaCompletata, onAnnulla }) => {

    // Stato per il testo modificato del commento, inizializzato con il testo attuale
    const [testoModificato, setTestoModificato] = useState(commento.comment);
    // Stato per il voto modificato, inizializzato con il voto attuale
    const [votoModificato, setVotoModificato] = useState(commento.rate);
    // Stato per tracciare se è in corso l'invio della modifica
    const [invioInCorso, setInvioInCorso] = useState(false);
    // Stato per gestire eventuali errori durante la modifica
    const [errore, setErrore] = useState(null);

    // Funzione che gestisce l'invio del form di modifica
    const handleSubmit = (e) => {
        // Previene il comportamento di default del form
        e.preventDefault();
        // Imposta lo stato di invio a true
        setInvioInCorso(true);
        // Resetta eventuali errori precedenti
        setErrore(null);

        // Effettua la chiamata PUT all'API per modificare il commento
        fetch(`https://striveschool-api.herokuapp.com/api/comments/${commento._id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` // Include il token di autenticazione
            },
            // Corpo della richiesta con i dati modificati
            body: JSON.stringify({
                comment: testoModificato,      // Nuovo testo del commento
                rate: votoModificato           // Nuovo voto
            })
        })
        .then(response => {
            // Verifica se la risposta è ok
            if (response.ok) {
                return response.json();
            } else {
                // Se la risposta non è ok, lancia un errore
                throw new Error('Errore nella modifica del commento');
            }
        })
        .then(data => {
            // Se la modifica è avvenuta con successo, chiama la callback
            onModificaCompletata(data);
        })
        .catch(error => {
            // Gestisce e memorizza eventuali errori
            setErrore(error.message);
        })
        .finally(() => {
            // Alla fine, indipendentemente dal risultato, imposta invioInCorso a false
            setInvioInCorso(false);
        });
    }

    // Rendering del form di modifica
    return (
        <Form onSubmit={handleSubmit}>
            {/* Campo di testo per modificare il commento */}
            <Form.Group className="mb-3">
                <Form.Control
                as="textarea"
                rows={3}            
                value={testoModificato}
                onChange={(e) => setTestoModificato(e.target.value)} />
            </Form.Group>

            {/* Select per modificare il voto */}
            <Form.Group className="mb-3">
                <Form.Select    
                value={votoModificato}
                onChange={(e) => setVotoModificato(e.target.value)}>
                    {/* Genera le opzioni da 1 a 5 */}
                    {[1, 2, 3, 4, 5].map((num) => (
                        <option key={num} value={num}>{num}</option>
                    ))}
                </Form.Select>
            </Form.Group>

            {/* Mostra eventuali messaggi di errore */}
            {errore && (
                <div className="alert alert-danger">{errore}</div>
            )}

            {/* Container per i pulsanti di azione */}
            <div className="d-flex justify-content-end gap-2">
                {/* Pulsante per annullare la modifica */}
                <Button 
                variant='secondary'
                size='sm'   
                onClick={onAnnulla}>
                    Annulla
                </Button>
                {/* Pulsante per inviare la modifica */}
                <Button 
                type='submit'
                variant='primary'
                size='sm'
                disabled={invioInCorso}>
                    {invioInCorso ? 'Modificando...' : 'Modifica'}
                </Button>
            </div>
        </Form>
    )
}

// Esportiamo il componente per utilizzarlo in altre parti dell'applicazione
export default ModificaCommento;