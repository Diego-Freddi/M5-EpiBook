// Importiamo i componenti necessari da react-bootstrap per creare l'interfaccia utente
import { ListGroup, Button } from 'react-bootstrap';
// Importiamo useState da React per gestire lo stato interno del componente
import { useState } from 'react';
// Importiamo il componente ModificaCommento che gestirà la modifica dei commenti
import ModificaCommento from './ModificaCommento';

// Definiamo il componente ListaCommenti che riceve come props:
// - commenti: array dei commenti da visualizzare
// - token: token di autenticazione per le chiamate API
// - onCommentoEliminato: callback da chiamare quando un commento viene eliminato
// - onCommentoModificato: callback da chiamare quando un commento viene modificato
const ListaCommenti = ({ commenti, token, onCommentoEliminato, onCommentoModificato }) => {
    // Stato per tenere traccia dell'ID del commento attualmente in modifica (null se nessuno)
    const [commentoInModifica, setCommentoInModifica] = useState(null);

    // Funzione che gestisce l'eliminazione di un commento
    const handleElimina = (commentoId) => {
        // Effettua una chiamata DELETE all'API per eliminare il commento
        fetch(`https://striveschool-api.herokuapp.com/api/comments/${commentoId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}` // Include il token di autenticazione
            }
        })
        .then(response => {
            if (response.ok) {
                // Se l'eliminazione è avvenuta con successo, notifica il componente padre
                onCommentoEliminato();
            } else {
                // Se c'è un errore, lancia un'eccezione
                throw new Error('Errore durante l\'eliminazione del commento');
            }
        })
        .catch(error => {
            // Gestisce e logga eventuali errori
            console.error('Errore:', error);
        });
    };

    return (
        // Contenitore principale che usa ListGroup di Bootstrap con margine superiore
        <ListGroup className='mt-2'>
            {/* Itera su ogni commento nell'array per crearli visivamente */}
            {commenti.map((commento) => (
                // Ogni commento è un elemento della lista con chiave unica basata sul suo ID
                <ListGroup.Item key={commento._id}>
                    {/* Rendering condizionale: mostra form di modifica o visualizzazione normale */}
                    {commentoInModifica === commento._id ? (
                        // Se il commento è in modifica, mostra il componente ModificaCommento
                        <ModificaCommento 
                            commento={commento}
                            token={token}
                            onModificaCompletata={() => {
                                // Quando la modifica è completata, resetta lo stato e notifica il padre
                                setCommentoInModifica(null);
                                onCommentoModificato();
                            }}
                            onAnnulla={() => setCommentoInModifica(null)} // Gestisce l'annullamento
                        />
                    ) : (
                        // Se il commento non è in modifica, mostra la visualizzazione normale
                        <div className="d-flex justify-content-between align-items-center">
                            {/* Contenitore per il testo del commento e il voto */}
                            <div>
                                <p className="mb-1">{commento.comment}</p>
                                <small className="text-muted">
                                    Voto: {commento.rate} ★
                                </small>
                            </div>
                            {/* Contenitore per i pulsanti di azione */}
                            <div>
                                <Button 
                                    variant="outline-primary" 
                                    size="sm" 
                                    className="me-2"
                                    onClick={() => setCommentoInModifica(commento._id)}
                                >
                                    Modifica
                                </Button>
                                <Button 
                                    variant="outline-danger" 
                                    size="sm"
                                    onClick={() => handleElimina(commento._id)}
                                >
                                    Elimina
                                </Button>
                            </div>
                        </div>
                    )}
                </ListGroup.Item>
            ))}
        </ListGroup>
    )
}

// Esporta il componente per permetterne l'utilizzo in altre parti dell'applicazione
export default ListaCommenti;