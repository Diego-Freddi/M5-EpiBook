import './App.css';
import MyNavbar from './component/navbar.js';
import { Container } from 'react-bootstrap';
import Books from './component/books.js';
import Footer from './component/Footer.js';
import { useState } from 'react';

function App() {
  const [search, setSearch] = useState('');
  const [selectedGenere, setSelectedGenere] = useState('all');

  const handleSearchChange = (searchText) => {
    setSearch(searchText);
  };

  const handleGenereChange = (genere) => {
    setSelectedGenere(genere);
  };

  return (
    <>
      <MyNavbar 
        onSearchChange={handleSearchChange}
        onGenereChange={handleGenereChange}
      />
      <Container>
       <Books
        searchQuery={search}
        sceltaGenere={selectedGenere}/>
      </Container>
      <Footer />
    </>
  );
}

export default App;
