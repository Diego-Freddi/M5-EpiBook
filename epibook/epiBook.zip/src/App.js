import './App.css';
import MyNavbar from './component/navbar.js';
import { Container } from 'react-bootstrap';
import Books from './component/books.js';
import Footer from './component/Footer.js';
import { useState } from 'react';
import ThemeProvider, { useTheme } from './context/ThemeContext.jsx';

function AppContent() {
  const [search, setSearch] = useState('');
  const [selectedGenere, setSelectedGenere] = useState('all');
  const { theme } = useTheme();

  const handleSearchChange = (searchText) => {
    setSearch(searchText);
  };

  const handleGenereChange = (genere) => {
    setSelectedGenere(genere);
  };

  return (
    <div className={`df-app-container ${theme === 'scuro' ? 'df-dark-mode' : ''}`}>
      <MyNavbar
        onSearchChange={handleSearchChange}
        onGenereChange={handleGenereChange}
      />
      <Container>
        <Books
          searchQuery={search}
          sceltaGenere={selectedGenere}
        />
      </Container>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;
