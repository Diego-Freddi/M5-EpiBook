import { Card } from 'react-bootstrap';
import { useState } from 'react';
import AreaCommenti from './AreaCommenti';

const SingleBook = ({book, theme}) => {
    const [selected, setSelected] = useState(false);

    return (
        <>
        <Card
        className={`book-card ${selected ? 'selected' : ''} mt-3 ${theme === 'scuro' ? 'df-dark-mode' : ''}`}
        onClick={() => setSelected(!selected)}
        >
            <div className="img-container"
            style={{
                height: '25rem',
                backgroundImage: `url(${book.img})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat',
            }}>
            </div>  
            <Card.Body>
                <Card.Title className='flex-grow-1'>{book.title.substring(0, 20)}...</Card.Title>
                <div className='d-flex justify-content-between'>
                    <Card.Text className={theme === 'scuro' ? 'text-white' : ''}>{book.category}</Card.Text>
                    <Card.Text className={theme === 'scuro' ? 'text-white' : ''}>{book.price}€</Card.Text>
                </div>
            </Card.Body>    
        </Card>
        {selected && <AreaCommenti codiceLibro={book.asin} theme={theme} />}
        </>
    )
}

export default SingleBook;  